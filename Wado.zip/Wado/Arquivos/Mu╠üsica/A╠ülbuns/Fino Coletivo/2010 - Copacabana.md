___
___
# [Fino Coletivo](https://www.discogs.com/artist/3079458-Fino-Coletivo)

![Fino Coletivo - Copacabana album cover](<missing>)

| | |
|---|---|
|## Selo:|<missing>|
|## Formato:|[CD](https://www.discogs.com/search/?format_exact=CD)|
|## País:|[Brazil](https://www.discogs.com/search/?country_exact=Brazil)|
|## Lançado:|[2010](https://www.discogs.com/search/?year=2010)|
|## Gênero:|[Latin](https://www.discogs.com/search/?genre_exact=Latin)|
|## Estilo:|<missing>|

## Lista de faixas

| | | | |
|---|---|---|---|
|1||Batida de Trovão|3:35|
|2||A Coisa Mais Linda do Mundo|3:56|
|3||Ai de Mim|3:29|
|4||Doce em Madrid|1:35|
|5||Fidelidade|4:06|
|6||Bravo Mar|3:32|
|7||Minha Menina Bonita|3:58|
|8||Beijou Você|3:16|
|9||Abalando Geral|3:13|
|10||Swing do Campo Grande|3:45|
|11||Nhem Nhem Nhem|4:41|
|12||Se Vacilar o Jacaré Abraça|3:31|
|13||Velho Dia|3:29|
|14||Amor Meu|7:56|

## Companhias, etc.

- <missing>

## Créditos

- <missing>

## Código de Barras e Outros Identificadores

- <missing>