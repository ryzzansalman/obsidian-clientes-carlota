___
# [Fino Coletivo](https://www.discogs.com/artist/3079458-Fino-Coletivo)

![Fino Coletivo - Fino Coletivo album cover](<missing>)

| | |
|---|---|
|## Selo:|[Dubas](https://www.discogs.com/label/91903-Dubas)|
|## Formato:|[CD](https://www.discogs.com/search/?format_exact=CD)|
|## País:|[Brazil](https://www.discogs.com/search/?country_exact=Brazil)|
|## Lançado:|[2007](https://www.discogs.com/search/?year=2007)|
|## Gênero:|[Eletronic, MPB](https://www.discogs.com/search/?genre_exact=Electronic)|
|## Estilo:|[Samba-rock](https://www.discogs.com/style/Samba-rock)|

## Lista de faixas

| | | | |
|---|---|---|---|
|1||Boa Hora|3:47|
|2||Dragão|<missing>|
|3||Partiu Partindo|<missing>|
|4||Na Maior Alegria|<missing>|
|5||Medo da Briga|<missing>|
|6||Tarja Preta/Fafá|<missing>|
|7||<missing>|<missing>|
|8||<missing>|<missing>|
|9||<missing>|<missing>|
|10||<missing>|<missing>|
|11||<missing>|<missing>|
|12||<missing>|<missing>|

## Companhias, etc.

- <missing>

## Créditos

- Vocais, Guitarra – [Wado](https://www.discogs.com/artist/1071855-Wado)
- Guitarra, Vocais – [Alvinho Cabral](https://www.discogs.com/artist/3079460-Alvinho-Cabral)
- Guitarra, Vocais – [Marcelo Frota (aka Momo)](https://www.discogs.com/artist/1071854-Momo-5)
- Vocais – [Alvinho Lancellotti](https://www.discogs.com/artist/3079461-Alvinho-Lancellotti)
- Vocais – [Adriano Siri](https://www.discogs.com/artist/3079462-Adriano-Siri)
- Baixo, Programação – [Daniel Medeiros](https://www.discogs.com/artist/3079463-Daniel-Medeiros)
- Bateria – [Marcus Coruja](https://www.discogs.com/artist/3079459-Marcus-Coruja)

## Código de Barras e Outros Identificadores

- Código de Barras: 6 02517 21248 0