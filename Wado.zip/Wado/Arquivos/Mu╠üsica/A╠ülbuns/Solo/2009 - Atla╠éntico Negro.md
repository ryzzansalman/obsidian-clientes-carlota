___
# [Wado](https://www.discogs.com/artist/1875521-Wado) – [Atlântico Negro](https://open.spotify.com/album/6flbrDabNvJpOdK4swLbGT)

[

![Wado - Atlântico Negro album cover](https://i.discogs.com/CvZYku0FuQIim242zXqS766eOL44vOkNPF8T_9bYvXE/rs:fit/g:sm/q:40/h:300/w:300/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTE1NDA3/NzQxLTE1OTEwMzU1/MDUtODc2OC53ZWJw.jpeg)

More images

](https://www.discogs.com/release/15407741-Wado-Atl%C3%A2ntico-Negro/image/SW1hZ2U6NDY4MTk3NjY=)

|   |   |
|---|---|
|## Label:|[Not On Label](https://www.discogs.com/label/1818-Not-On-Label) – WADO02SMD|
|## Format:|[CD](https://www.discogs.com/search/?format_exact=CD), Album, _SMD_|
|## Country:|[Brazil](https://www.discogs.com/search/?country=Brazil)|
|## Released:|[2009](https://www.discogs.com/search/?decade=2000&year=2009)|
|## Genre:|[Latin](https://www.discogs.com/genre/latin), [Pop](https://www.discogs.com/genre/pop)|
|## Style:||

## Tracklist

Hide Credits

|   |   |   |
|---|---|---|
|1||Estrada<br><br>Written By – [Dinho Zampier](https://www.discogs.com/artist/3656983-Dinho-Zampier), [Mia Couto](https://www.discogs.com/artist/6419430-Mia-Couto), [Wado](https://www.discogs.com/artist/1875521-Wado)<br><br>Written By – [Dinho Zampier](https://www.discogs.com/artist/3656983-Dinho-Zampier), [Mia Couto](https://www.discogs.com/artist/6419430-Mia-Couto), [Wado](https://www.discogs.com/artist/1875521-Wado)|
|2||Atlântico Negro<br><br>Written By – [Beto Brito](https://www.discogs.com/artist/5624215-Beto-Brito), [Dinho Zampier](https://www.discogs.com/artist/3656983-Dinho-Zampier), [Fernando Coelho](https://www.discogs.com/artist/6072996-Fernando-Coelho), [Wado](https://www.discogs.com/artist/1875521-Wado)<br><br>Written By – [Beto Brito](https://www.discogs.com/artist/5624215-Beto-Brito), [Dinho Zampier](https://www.discogs.com/artist/3656983-Dinho-Zampier), [Fernando Coelho](https://www.discogs.com/artist/6072996-Fernando-Coelho), [Wado](https://www.discogs.com/artist/1875521-Wado)|
|3||Jejum / Cavaleiro De Aruanda - Pot-Pourri<br><br>Written By – [Tony Osanah](https://www.discogs.com/artist/956899-Tony-Osanah), [Wado](https://www.discogs.com/artist/1875521-Wado)<br><br>Written By – [Tony Osanah](https://www.discogs.com/artist/956899-Tony-Osanah), [Wado](https://www.discogs.com/artist/1875521-Wado)|
|4||Martelo De Ogum<br><br>Written By – [Dinho Zampier](https://www.discogs.com/artist/3656983-Dinho-Zampier), [Wado](https://www.discogs.com/artist/1875521-Wado)<br><br>Written By – [Dinho Zampier](https://www.discogs.com/artist/3656983-Dinho-Zampier), [Wado](https://www.discogs.com/artist/1875521-Wado)|
|5||Cordão De Isolamento<br><br>Written By – [Dinho Zampier](https://www.discogs.com/artist/3656983-Dinho-Zampier), [Wado](https://www.discogs.com/artist/1875521-Wado)<br><br>Written By – [Dinho Zampier](https://www.discogs.com/artist/3656983-Dinho-Zampier), [Wado](https://www.discogs.com/artist/1875521-Wado)|
|6||Hercílio Luz<br><br>Written By – [Mia Couto](https://www.discogs.com/artist/6419430-Mia-Couto), [Wado](https://www.discogs.com/artist/1875521-Wado)<br><br>Written By – [Mia Couto](https://www.discogs.com/artist/6419430-Mia-Couto), [Wado](https://www.discogs.com/artist/1875521-Wado)|
|7||Pavão Macaco<br><br>Written By – [Wado](https://www.discogs.com/artist/1875521-Wado)<br><br>Written By – [Wado](https://www.discogs.com/artist/1875521-Wado)|
|8||Frágil<br><br>Written By – [Alvinho Cabral](https://www.discogs.com/artist/4531119-Alvinho-Cabral), [Wado](https://www.discogs.com/artist/1875521-Wado)<br><br>Written By – [Alvinho Cabral](https://www.discogs.com/artist/4531119-Alvinho-Cabral), [Wado](https://www.discogs.com/artist/1875521-Wado)|
|9||Feto / Sotaque - Pot-Pourri<br><br>Written By – [Alvinho Cabral](https://www.discogs.com/artist/4531119-Alvinho-Cabral), [Eduardo Bahia](https://www.discogs.com/artist/6750600-Eduardo-Bahia), [Wado](https://www.discogs.com/artist/1875521-Wado)<br><br>Written By – [Alvinho Cabral](https://www.discogs.com/artist/4531119-Alvinho-Cabral), [Eduardo Bahia](https://www.discogs.com/artist/6750600-Eduardo-Bahia), [Wado](https://www.discogs.com/artist/1875521-Wado)|
|10||Boa Tarde, Povo<br><br>Written By – [Maria Do Carmo Barbosa De Melo](https://www.discogs.com/artist/3513821-Maria-Do-Carmo-Barbosa-De-Melo)<br><br>Written By – [Maria Do Carmo Barbosa De Melo](https://www.discogs.com/artist/3513821-Maria-Do-Carmo-Barbosa-De-Melo)|
|11||Rap Guerra No Iraque<br><br>Written By – [Mc Gil Do Andaraí](https://www.discogs.com/artist/7923381-Mc-Gil-Do-Andara%C3%AD)<br><br>Written By – [Mc Gil Do Andaraí](https://www.discogs.com/artist/7923381-Mc-Gil-Do-Andara%C3%AD)|

## Companies, etc.

- Recorded At – [Gravamusic](https://www.discogs.com/label/644149-Gravamusic)
- Recorded At – [Sagaz Estúdio](https://www.discogs.com/label/1840465-Sagaz-Est%C3%BAdio)
- Recorded At – [Estúdio Do Chico Da Cruz Das Almas](https://www.discogs.com/label/1840466-Est%C3%BAdio-Do-Chico-Da-Cruz-Das-Almas)

## Credits

- Artwork By – [Jorge Carlos](https://www.discogs.com/artist/157330-Jorge-Carlos)
- Mixed By – [Beto Machado](https://www.discogs.com/artist/856796-Beto-Machado) (tracks: 4, 6, 7, 8, 9), [Kassin](https://www.discogs.com/artist/280221-Kassin) (tracks: 1, 2, 3, 5, 10, 11)
- Photography By, Production Manager – [Maíra Villela](https://www.discogs.com/artist/6750564-Ma%C3%ADra-Villela)
- Producer – [Pedro Ivo Euzébio](https://www.discogs.com/artist/4539948-Pedro-Ivo-Euz%C3%A9bio)
- Production Manager – [Luciana Fonseca](https://www.discogs.com/artist/7923382-Luciana-Fonseca)
- Production Manager, Lead Vocals, Artwork By – [Wado](https://www.discogs.com/artist/1875521-Wado)

## Matérias importantes
https://www.screamyell.com.br/blog/2009/08/05/atlantico-negro-de-wado-para-download/