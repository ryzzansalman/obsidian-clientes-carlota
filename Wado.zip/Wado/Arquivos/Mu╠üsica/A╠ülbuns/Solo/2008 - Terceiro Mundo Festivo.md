___
# [Wado](https://www.discogs.com/artist/1875521-Wado) – [Terceiro Mundo Festivo](https://open.spotify.com/album/7aon0unQCqT1FnLUl6RdWR)

[

![Wado - Terceiro Mundo Festivo album cover](https://i.discogs.com/b_K0JpJLD1lmTLQv-wMRn0vYGGYsFxQod5w8v_oZJY0/rs:fit/g:sm/q:40/h:300/w:300/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTEwMDQw/NDI4LTE0OTA1Njc1/NjgtNjUxOC5qcGVn.jpeg)

](https://www.discogs.com/release/10040428-Wado-Terceiro-Mundo-Festivo/image/SW1hZ2U6Mjc3MzgzNjI=)

|   |   |
|---|---|
|## Label:|[Not On Label](https://www.discogs.com/label/1818-Not-On-Label) – WADOSMD|
|## Format:|[CD](https://www.discogs.com/search/?format_exact=CD), Album, _SMD_|
|## Country:|[Brazil](https://www.discogs.com/search/?country=Brazil)|
|## Released:|[2008](https://www.discogs.com/search/?decade=2000&year=2008)|
|## Genre:|[Electronic](https://www.discogs.com/genre/electronic), [Rock](https://www.discogs.com/genre/rock), [Latin](https://www.discogs.com/genre/latin), [Pop](https://www.discogs.com/genre/pop)|
|## Style:|[MPB](https://www.discogs.com/style/mpb)|

## Tracklist

|     |     |                       |
| --- | --- | --------------------- |
| 1   |     | Pendurado             |
| 2   |     | Melhor                |
| 3   |     | Fortalece Aí          |
| 4   |     | Teta                  |
| 5   |     | Reforma Agrária do Ar |
| 6   |     | Fita Bruta            |
| 7   |     | Tema Fita Bruta       |
| 8   |     | Leva                  |
| 9   |     | Faz-me Rir            |
| 10  |     | Lucrécia              |
| 11  |     | Recado                |
## Matérias importantes
https://screamyell.com.br/site/2008/02/11/disco-da-semana-terceiro-mundo-festivo-de-wado/