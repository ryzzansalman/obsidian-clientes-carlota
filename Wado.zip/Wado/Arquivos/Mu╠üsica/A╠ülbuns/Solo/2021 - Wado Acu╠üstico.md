___
# [Wado](https://www.discogs.com/artist/1071855-Wado) - [Wado Acústico](https://open.spotify.com/album/6G7IfM6VNzs2fzPRH3ilWx)

![Wado - Wado Acústico album cover](<missing>)

| | |
|---|---|
|## Selo:|[LAB 344](https://music.apple.com/us/artist/wado/208776074)|
|## Formato:|[Digital](https://www.discogs.com/search/?format_exact=Digital)|
|## País:|[Brazil](https://www.discogs.com/search/?country_exact=Brazil)|
|## Lançado:|[10 de dezembro de 2021](https://revistaogrito.com/wado-lanca-projeto-acustico-e-antecipa-primeiro-single-correntes-comprimidas/)|
|## Gênero:|[MPB, Acústico](https://www.discogs.com/search/?genre_exact=MPB)|
|## Estilo:|[Acústico, Folk](https://www.discogs.com/style/Folk)|

## Lista de faixas

| | | | |
|---|---|---|---|
|1||Correntes Comprimidas|<missing>|
|2||<missing>|<missing>|
|3||<missing>|<missing>|
|4||<missing>|<missing>|
|5||<missing>|<missing>|
|6||<missing>|<missing>|
|7||<missing>|<missing>|
|8||<missing>|<missing>|
|9||<missing>|<missing>|
|10||<missing>|<missing>|
|11||<missing>|<missing>|
|12||Aquele Frevo Axé (feat. Patricia Marx) [Bônus]|<missing>|

## Companhias, etc.

- [[missing]]

## Créditos

- Produtor – [[missing]]
- Direção Audiovisual – [Duda Bertho](https://www.discogs.com/artist/)
- Gravação, Mixagem e Masterização – [Jair Donato](https://www.discogs.com/artist/)
- Composição – Wado, Vitor Peixoto (Faixa 1)
- Composição – Cezar Mendes, Caetano Veloso (Faixa 12)
- Participação – [Patricia Marx](https://www.discogs.com/artist/) (Faixa 12)

## Código de Barras e Outros Identificadores

- [[missing]]

## Matérias importantes
https://revistaogrito.com/wado-lanca-projeto-acustico-e-antecipa-primeiro-single-correntes-comprimidas/