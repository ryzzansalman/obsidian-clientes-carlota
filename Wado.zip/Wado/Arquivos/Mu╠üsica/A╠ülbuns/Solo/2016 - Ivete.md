___
# [Wado](https://www.discogs.com/artist/1071855-Wado) - [Ivete](https://open.spotify.com/album/5JQwhg6Tym1F5DhXTjXpyB)

![Wado - Ivete album cover](<missing>)

| | |
|---|---|
|## Selo:|[Independente / Tratore](https://tratore.com.br/)|
|## Formato:|[CD, Digital](https://www.discogs.com/search/?format_exact=CD)|
|## País:|[Brazil](https://www.discogs.com/search/?country_exact=Brazil)|
|## Lançado:|[5 de julho de 2016](https://music.apple.com/br/album/ivete/1128164038)|
|## Gênero:|[MPB, Axé](https://www.discogs.com/search/?genre_exact=MPB)|
|## Estilo:|[Afro-pop-baiana](https://www.discogs.com/style/)|

## Lista de faixas

| | | | |
|---|---|---|---|
|1||Alabama|<missing>|
|2||Terra Santa / Jesus é Palestino|1:47|
|3||Um Passo à Frente|<missing>|
|4||Sexo|<missing>|
|5||Mistério|<missing>|
|6||Filhos de Gandhi|<missing>|
|7||Você Não Vem|<missing>|
|8||Samba de Amor|<missing>|
|9||Amanheceu|<missing>|
|10||Nós|<missing>|

## Companhias, etc.

- Distribuído por – [Tratore](https://tratore.com.br/)

## Créditos

- Produtor – [Wado](https://www.discogs.com/artist/1071855-Wado)
- Projeto Gráfico – [Dorgi Barros / Pana](https://www.discogs.com/artist/)
- Compositor – Wado, Thiago Silva (Faixas 1, 4)
- Compositor – Wado, Junior Almeida, Dinho Zampier (Faixa 2)
- Compositor – Carlinhos Brown, Gerônimo Santana, Alain Tavares (Trecho "Ralé (Jesus é palestino)" na Faixa 2)
- Compositor – Moreno Veloso, Quito Ribeiro (Faixa 3)
- Compositor – Wado, Zeca Baleiro (Faixas 5, 10)
- Compositor – Gilberto Gil (Faixa 6)
- Compositor – Wado, Momo, Marcelo Camelo (Faixa 7)
- Compositor – Alvinho Lancelotti, MoMo (Faixa 8)
- Compositor – Wado, Beto Bryto (Faixa 9)

## Código de Barras e Outros Identificadores

[[missing]]

## Matérias importantes
https://oglobo.globo.com/cultura/musica/ivete-ouviu-adorou-ivete-novo-disco-do-wado-19814545
