___
# [Wado](https://www.discogs.com/artist/1875521-Wado) e [Realismo Fantástico](https://www.discogs.com/artist/6710816-Realismo-Fant%C3%A1stico) – [A Farsa Do Samba Nublado](https://open.spotify.com/album/3ylsx6fHEPY61JBYL8imA1)

[

![Wado - A Farsa Do Samba Nublado album cover](https://i.discogs.com/9wHuzdt9e4sWSI5cof7rfMv3nPsTojz-VSU3_q5KBew/rs:fit/g:sm/q:40/h:300/w:300/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTg2MDQ2/NjQtMTY2NDg0MDc1/MC00MjcyLmpwZWc.jpeg)

](https://www.discogs.com/release/8604664-Wado-e-Realismo-Fant%C3%A1stico-A-Farsa-Do-Samba-Nublado/image/SW1hZ2U6ODQ0NjMxMDM=)

|   |   |
|---|---|
|## Label:|[Tratore](https://www.discogs.com/label/139793-Tratore) – ODD030#2004|
|## Format:|[CD](https://www.discogs.com/search/?format_exact=CD), Album|
|## Country:|[Brazil](https://www.discogs.com/search/?country=Brazil)|
|## Released:|[2004](https://www.discogs.com/search/?decade=2000&year=2004)|
|## Genre:|[Rock](https://www.discogs.com/genre/rock), [Latin](https://www.discogs.com/genre/latin), [Pop](https://www.discogs.com/genre/pop)|
|## Style:|[MPB](https://www.discogs.com/style/mpb)|

## Tracklist

|   |   |   |
|---|---|---|
|1||Tormenta|
|2||Grande Poder|
|3||Vai Querer?|
|4||Alguma Coisa Mais Pra Frente|
|5||Carteiro de Favela|
|6||Gargalhada Fatal|
|7||Fuso|
|8||Amor E Restos Humanos|
|9||Se Vacilar O Jacaré Abraça|
|10||Ode à Maldade|
|11||Deserto de Sal|
|12||Bonus Tracks: Pé de Carambola|

## Notes

BRAZILIAN SINGER/COMPOSER

## Matérias importantes
https://www1.folha.uol.com.br/fsp/ilustrad/fq1911200422.htm