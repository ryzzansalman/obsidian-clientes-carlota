___
# [Wado](https://www.discogs.com/artist/1071855-Wado) - [O Clube dos Jovens de Ontem](https://open.spotify.com/album/0bBA3c063AguxlLSlcmYJK)

![Wado - O Clube dos Jovens de Ontem album cover](<missing>)

| | |
|---|---|
|## Selo:|[Saravá Discos](https://zecabaleiro.com.br/wado-o-clube-dos-jovens-de-ontem/)|
|## Formato:|[Digital](https://www.discogs.com/search/?format_exact=Digital)|
|## País:|[Brazil](https://www.discogs.com/search/?country_exact=Brazil)|
|## Lançado:|[8 de dezembro de 2023](https://music.apple.com/br/album/o-clube-dos-jovens-de-ontem/1722463931)|
|## Gênero:|[MPB](https://www.discogs.com/search/?genre_exact=MPB)|
|## Estilo:|[Pop, Rock](https://www.discogs.com/style/Pop)|

## Lista de faixas

| | | | |
|---|---|---|---|
|1||Terminal Marajoara (feat. Saulo Schwartzmann)|<missing>|
|2||Álcool ou Acetona|<missing>|
|3||Dente D'Ouro|<missing>|
|4||Copa Larga|<missing>|
|5||Constelações (feat. May Honorato)|<missing>|
|6||Meu Caso Preferido|<missing>|
|7||Cazimi|<missing>|
|8||Trovejar|<missing>|

## Companhias, etc.

- Distribuído por – [ONErpm](https://portalpepper.com.br/wado-divulga-o-clube-dos-jovens-de-ontem-album-com-rara-parceria-de-marcelo-camelo/)

## Créditos

- Produtor, Voz, Violão – [Wado](https://www.discogs.com/artist/1071855-Wado)
- Guitarra – [Vitor Peixoto](https://www.discogs.com/artist/)
- Baixo – [Igor Peixoto](https://www.discogs.com/artist/)
- Bateria – [Rodrigo Sarmento](https://www.discogs.com/artist/)
- Sintetizadores, Voz de Apoio, Mixagem, Masterização – [Jair Donato](https://www.discogs.com/artist/)
- Participação – [Saulo Schwartzmann](https://www.discogs.com/artist/) (Faixa 1)
- Participação – [May Honorato](https://www.discogs.com/artist/) (Faixa 5)
- Compositor – Wado, Carol Tomasi, Saulo Schwartzmann (Faixa 1)
- Compositor – Naurêa (Faixa 2)
- Compositor – Wado, Momo, Marcelo Camelo (Faixa 3)
- Compositor – Wado (Faixa 4)
- Compositor – Wado, May Honorato (Faixa 5)
- Compositor – [[missing]] (Faixa 6)
- Compositor – [[missing]] (Faixa 7)
- Compositor – Wado, Thiago Silva (Faixa 8)

## Código de Barras e Outros Identificadores

[[missing]]

## Matérias importantes

https://g1.globo.com/pop-arte/musica/blog/mauro-ferreira/post/2023/12/06/wado-inclui-marcelo-camelo-no-clube-dos-jovens-de-ontem-album-avalizado-por-zeca-baleiro.ghtml