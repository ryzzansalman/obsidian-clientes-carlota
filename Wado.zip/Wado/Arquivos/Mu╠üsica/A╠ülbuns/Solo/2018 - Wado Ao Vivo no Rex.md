___
# [Wado](https://www.discogs.com/artist/1071855-Wado) - [Wado Ao Vivo no Rex](https://open.spotify.com/album/3XBjUJEgjk2le36ENsnOeT)

![Wado - Wado Ao Vivo no Rex album cover](<missing>)

| | |
|---|---|
|## Selo:|[Independente](https://tratore.com.br/um_cd.php?id=12046)|
|## Formato:|[CD](https://www.discogs.com/search/?format_exact=CD)|
|## País:|[Brazil](https://www.discogs.com/search/?country_exact=Brazil)|
|## Lançado:|[9 de março de 2018](https://open.spotify.com/album/3XBjUJEgjk2le36ENsnOeT)|
|## Gênero:|[MPB](https://www.discogs.com/search/?genre_exact=MPB)|
|## Estilo:|<missing>|

## Lista de faixas

| | | | |
|---|---|---|---|
|1||Sexo (Ao Vivo)|2:16|
|2||Um Passo à Frente (Ao Vivo)|3:08|
|3||Sotaque (Ao Vivo)|2:04|
|4||Estrada (Ao Vivo)|4:20|
|5||Alabama (Ao Vivo)|2:20|
|6||Filhos de Gandhi (Ao Vivo)|3:18|
|7||Terra Santa (Ao Vivo)|1:52|
|8||Com a Ponta dos Dedos (Ao Vivo)|3:53|
|9||Rosa (Ao Vivo)|2:33|
|10||Crua (Ao Vivo)|3:52|
|11||Surdos de Escola de Samba (Ao Vivo)|3:40|
|12||Tarja Preta / Fafá (Ao Vivo)|4:48|
|13||Cidade Grande (Ao Vivo)|3:08|
|14||Fortalece Aí (Ao Vivo)|3:01|

## Companhias, etc.

- Distribuído por – [Tratore](https://tratore.com.br/)

## Créditos

- Intérprete – [Wado](https://www.discogs.com/artist/1071855-Wado)
- Autor – Thiago Silva, Wado (Faixa 1)
- Autor – Moreno Veloso, Quito Ribeiro (Faixa 2)
- Autor – Alvinho Cabral, Eduardo Bahia, Wado (Faixa 3)
- Autor – Dinho Zampier, Mia Couto, Wado (Faixa 4)
- Autor – Thiago Silva, Wado (Faixa 5)
- Autor – Gilberto Gil (Faixa 6)
- Autor – Dinho Zampier, Junior Almeida, Wado (Faixa 7)
- Autor – Glauber Xavier, Wado (Faixa 8)
- [[missing]] (Faixas 9-14)

## Código de Barras e Outros Identificadores

- Código de Barras: 7899989925366
- Código do Catálogo: WadoAoVivo01

## Matérias importantes
https://monkeybuzz.com.br/novidades/wado-anuncia-dvd-wado-ao-vivo-no-rex-jazzbar/