___
# [Wado](https://www.discogs.com/artist/1071855-Wado) - [A Beleza que Deriva do Mundo, mas a ele Escapa](https://open.spotify.com/album/4r3WmCyAL8kyYD8Z2ButhZ)

![Wado - A Beleza que Deriva do Mundo, mas a ele Escapa album cover](<missing>)

| | |
|---|---|
|## Selo:|[LAB 344](https://music.apple.com/br/album/a-beleza-que-deriva-do-mundo-mas-a-ele-escapa/1531493523)|
|## Formato:|[Digital](https://www.discogs.com/search/?format_exact=Digital)|
|## País:|[Brazil](https://www.discogs.com/search/?country_exact=Brazil)|
|## Lançado:|[2 de outubro de 2020](https://open.spotify.com/album/4r3WmCyAL8kyYD8Z2ButhZ)|
|## Gênero:|[MPB](https://www.discogs.com/search/?genre_exact=MPB)|
|## Estilo:|[Acústico, Folk](https://www.discogs.com/style/Folk)|

## Lista de faixas

| | | | |
|---|---|---|---|
|1||Faz Comigo (feat. FLORA)|<missing>|
|2||Nanã (feat. Otto)|<missing>|
|3||Nina (feat. Lucas Santtana)|<missing>|
|4||Tempo Vago (feat. Kassin, LoreB)|<missing>|
|5||Angola (feat. Zé Manoel, Thiago Silva, Alfredo Bello)|<missing>|
|6||Cacos (feat. Llari, Thiago Silva)|<missing>|
|7||Para Anthony Bourdain (feat. Cris Braun)|<missing>|
|8||Arcos (feat. Felipe de Vas, Yo Soy Toño)|<missing>|
|9||Quem Somos Nós (feat. Júnior Almeida, LoreB)|<missing>|
|10||Cuida (feat. Felipe de Vas, LoreB)|<missing>|
|11||Depois do Fim (feat. Zeca Baleiro, Patrícia Ahmaral)|<missing>|
|12||Sereno Canto|<missing>|

## Companhias, etc.

- [[missing]]

## Créditos

- Produtor – [Wado](https://www.discogs.com/artist/1071855-Wado)
- Arranjos de Cordas – [Jair Donato](https://www.discogs.com/artist/)
- Participação – [FLORA](https://www.discogs.com/artist/) (Faixa 1)
- Participação – [Otto](https://www.discogs.com/artist/) (Faixa 2)
- Participação – [Lucas Santtana](https://www.discogs.com/artist/) (Faixa 3)
- Participação – [Kassin](https://www.discogs.com/artist/), [LoreB](https://www.discogs.com/artist/) (Faixa 4)
- Participação – [Zé Manoel](https://www.discogs.com/artist/), [Thiago Silva](https://www.discogs.com/artist/), [Alfredo Bello](https://www.discogs.com/artist/) (Faixa 5)
- Participação – [Llari](https://www.discogs.com/artist/), [Thiago Silva](https://www.discogs.com/artist/) (Faixa 6)
- Participação – [Cris Braun](https://www.discogs.com/artist/) (Faixa 7)
- Participação – [Felipe de Vas](https://www.discogs.com/artist/), [Yo Soy Toño](https://www.discogs.com/artist/) (Faixa 8)
- Participação – [Júnior Almeida](https://www.discogs.com/artist/), [LoreB](https://www.discogs.com/artist/) (Faixa 9)
- Participação – [Felipe de Vas](https://www.discogs.com/artist/), [LoreB](https://www.discogs.com/artist/) (Faixa 10)
- Participação – [Zeca Baleiro](https://www.discogs.com/artist/), [Patrícia Ahmaral](https://www.discogs.com/artist/) (Faixa 11)

## Código de Barras e Outros Identificadores

- [[missing]]

## Matérias importantes
https://monkeybuzz.com.br/resenhas/albuns/wado-a-beleza-que-deriva-do-mundo-mas-a-ele-escapa
