___
# [Wado](https://www.discogs.com/artist/1875521-Wado) – [Vazio Tropical](https://open.spotify.com/album/6d4jDRwj5SXYTKB4e0gj0d)

[

![Wado - Vazio Tropical album cover](https://i.discogs.com/MO8EOx75sRUeHyrXEiVCXvCuddVWQ8YRjfP5klFB8VI/rs:fit/g:sm/q:40/h:300/w:300/czM6Ly9kaXNjb2dz/LWRhdGFiYXNlLWlt/YWdlcy9SLTEwMDQw/NTYwLTE0OTA1Njk4/NDctNTg3NS5qcGVn.jpeg)

](https://www.discogs.com/release/10040560-Wado-Vazio-Tropical/image/SW1hZ2U6Mjc3Mzg3MzM=)

|   |   |
|---|---|
|## Label:|[Microservice](https://www.discogs.com/label/266707-Microservice) – 648240|
|## Format:|[CD](https://www.discogs.com/search/?format_exact=CD), Album|
|## Country:|[Brazil](https://www.discogs.com/search/?country=Brazil)|
|## Released:|[2013](https://www.discogs.com/search/?decade=2010&year=2013)|
|## Genre:|[Latin](https://www.discogs.com/genre/latin)|
|## Style:|[MPB](https://www.discogs.com/style/mpb)|

## Tracklist

|   |   |   |
|---|---|---|
|1||Cidade Grande|
|2||Rosa|
|3||Canto dos Insetos|
|4||Carne|
|5||Flores do Bem|
|6||Quarto Sem Porta|
|7||Zelo|
|8||Tão Feliz|
|9||Primavera Árabe|
|10||Cais Abandonado|
|11||Vazio Tropical|

## Credits

- Co-producer – [Fred Ferreira](https://www.discogs.com/artist/1806389-Fred-Ferreira)
- Producer – [Marcelo Camelo](https://www.discogs.com/artist/702210-Marcelo-Camelo)
- Recorded By – [Bernardo Barata](https://www.discogs.com/artist/1582903-Bernardo-Barata)

## Matérias importantes
https://monkeybuzz.com.br/resenhas/albuns/wado-vazio-tropical/