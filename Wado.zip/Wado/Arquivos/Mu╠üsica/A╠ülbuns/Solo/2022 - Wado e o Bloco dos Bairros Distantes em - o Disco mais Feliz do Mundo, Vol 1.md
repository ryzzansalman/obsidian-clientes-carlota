___
# [Wado](https://www.discogs.com/artist/1071855-Wado) - [Wado e o Bloco dos Bairros Distantes em: o Disco mais Feliz do Mundo, Vol 1](https://open.spotify.com/album/4U3tMy6543rhWqXAMeOYUO)

![Wado - Wado e o Bloco dos Bairros Distantes em - o Disco mais Feliz do Mundo, Vol 1 album cover](<missing>)

| | |
|---|---|
|## Selo:|[Samba 808 / LAB 344](https://music.apple.com/br/album/wado-e-o-bloco-dos-bairros-distantes-em-o-disco-mais/1608026339)|
|## Formato:|[Digital](https://www.discogs.com/search/?format_exact=Digital)|
|## País:|[Brazil](https://www.discogs.com/search/?country_exact=Brazil)|
|## Lançado:|[25 de fevereiro de 2022](https://music.apple.com/br/album/wado-e-o-bloco-dos-bairros-distantes-em-o-disco-mais/1608026339)|
|## Gênero:|[MPB, Carnival](https://www.discogs.com/search/?genre_exact=MPB)|
|## Estilo:|[Samba, Axé](https://www.discogs.com/style/Samba)|

## Lista de faixas

| | | | |
|---|---|---|---|
|1||Joana Dark (feat. Fernanda Guimarães)|<missing>|
|2||Me Maten (feat. Janu, LoreB)|<missing>|
|3||Chão da Praça|<missing>|
|4||Segure Meu Bem (feat. LoreB)|<missing>|
|5||King Momo (feat. Aline Calixto)|<missing>|
|6||Chuva (feat. SERGIOPÍ)|<missing>|
|7||O Bonde Passa|<missing>|
|8||Aquele Frevo Axé (feat. Patricia Marx)|<missing>|

## Companhias, etc.

[[missing]]

## Créditos

- Produtor – [Wado](https://www.discogs.com/artist/1071855-Wado)
- Teclado – [Dinho Zampier](https://www.discogs.com/artist/)
- Guitarra, Vozes – [Vitor Peixoto](https://www.discogs.com/artist/)
- Baixo, Vozes – [Igor Peixoto](https://www.discogs.com/artist/)
- Cavaquinho, Banjo – [Salomão de Miranda](https://www.discogs.com/artist/)
- Palmas, Vozes – [Thiago Silva](https://www.discogs.com/artist/)
- Percussão – [Rodrigo Sarmento](https://www.discogs.com/artist/), [Leo Bulhoes](https://www.discogs.com/artist/), [[missing]]
- Participação – [Fernanda Guimarães](https://www.discogs.com/artist/) (Faixa 1)
- Participação – [Janu](https://www.discogs.com/artist/), [LoreB](https://www.discogs.com/artist/) (Faixa 2)
- Participação – [LoreB](https://www.discogs.com/artist/) (Faixa 4)
- Participação – [Aline Calixto](https://www.discogs.com/artist/) (Faixa 5)
- Participação – [SERGIOPÍ](https://www.discogs.com/artist/) (Faixa 6)
- Participação – [Patricia Marx](https://www.discogs.com/artist/) (Faixa 8)
- Compositor, Letrista – Ava Rocha, Victor Hugo, Gabriela Carneiro (Faixa 1)
- Compositor, Letrista – Cristian Quirante Catalán, Antonio Carmona Amaya, Victor Martinez Sanchez, Antonio Alvarez Alfaro (Faixa 2)
- Compositor, Letrista – Antonio Carlos Moraes Pires, Fausto Nilo Costa Junior (Faixa 3)
- Compositor, Letrista – David Nasser, Herivelto Martins (Faixa 4)
- Compositor, Letrista – Antonio Carlos Santos De Freitas (Faixa 5)
- Compositor, Letrista – Roosevelt Ribeiro De Carvalho (Faixa 6)
- Compositor, Letrista – [[missing]] (Faixa 7)
- Compositor – Caetano Veloso, Letrista – Cezar Mendes (Faixa 8)

## Código de Barras e Outros Identificadores

[[missing]]

## Matérias importantes
https://g1.globo.com/pop-arte/musica/blog/mauro-ferreira/post/2022/02/08/wado-traz-bloco-dos-bairros-distantes-para-o-disco-com-musicas-de-ava-rocha-moraes-moreira-e-russo-passapusso.ghtml