___
# [Wado](https://www.discogs.com/artist/1071855-Wado) & [Patricia Marx](https://www.discogs.com/artist/123180-Patricia-Marx) - [MARXWADO](https://open.spotify.com/album/2ejuTmpWcYt6eeA9kQNkuC)

![Wado & Patricia Marx - MARXWADO album cover](<missing>)

| | |
|---|---|
|## Selo:|[LAB 344](https://pt.wikipedia.org/wiki/MARXWADO)|
|## Formato:|[Digital](https://www.discogs.com/search/?format_exact=Digital)|
|## País:|[Brazil](https://www.discogs.com/search/?country_exact=Brazil)|
|## Lançado:|[3 de março de 2023](https://pt.wikipedia.org/wiki/MARXWADO)|
|## Gênero:|[MPB, Experimental](https://www.discogs.com/search/?genre_exact=MPB)|
|## Estilo:|[Funk Brasileiro, Samba-Rock](https://www.discogs.com/style/Samba)|

## Lista de faixas

| | | | |
|---|---|---|---|
|1||Vozes Trans|<missing>|
|2||Bom Parto|<missing>|
|3||Com a Ponta dos Dedos|<missing>|
|4||Me Deixa Em Paz|<missing>|
|5||Melhor|<missing>|
|6||Minha Voz, Minha Vida|<missing>|
|7||Orvalho|<missing>|

## Companhias, etc.

[[missing]]

## Créditos

- Produtor – [Wado](https://www.discogs.com/artist/1071855-Wado)
- Violão – [Vitor Peixoto](https://www.discogs.com/artist/)
- Baixo – [Igor Peixoto](https://www.discogs.com/artist/)
- Bateria – [Rodrigo Sarmento](https://www.discogs.com/artist/)
- Teclados – [Dinho Zampier](https://www.discogs.com/artist/)
- Mixagem, Masterização – [Jair Donato](https://www.discogs.com/artist/)
- Gravação Vocal – [Fabio Hataka](https://www.discogs.com/artist/)
- Fotografia – [Biga Pessoa](https://www.discogs.com/artist/)
- Compositor – Wado, Vitor Peixoto (Faixa 1)
- Compositor – Wado, Fernanda Coelho (Faixa 2)
- Compositor – Wado, Glauber Xavier (Faixa 3)
- Compositor – Monsueto Menezes, Airton Amorim (Faixa 4)
- Compositor – Wado, Adriano Siri (Faixa 5)
- Compositor – Caetano Veloso (Faixa 6)
- Compositor – Wado, Zeca Baleiro, Vitor Peixoto (Faixa 7)

## Código de Barras e Outros Identificadores

[[missing]]

## Matérias importantes
https://revistaogrito.com/patricia-marx-e-wado-fazem-som-brasileiro-e-experimental-no-disco-marxwado/