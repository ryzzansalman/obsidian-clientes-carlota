___
# [Wado](https://www.discogs.com/artist/1071855-Wado) - [Precariado](https://open.spotify.com/album/31ZgUAhbkzLWR23sYsNlHq)

![Wado - Precariado album cover](<missing>)

| | |
|---|---|
|## Selo:|[Independente / Tratore](https://tratore.com.br/um_cd.php?id=12560)|
|## Formato:|[Digital, CD](https://www.discogs.com/search/?format_exact=CD)|
|## País:|[Brazil](https://www.discogs.com/search/?country_exact=Brazil)|
|## Lançado:|[18 de maio de 2018](https://open.spotify.com/album/31ZgUAhbkzLWR23sYsNlHq)|
|## Gênero:|[MPB, Electronic](https://www.discogs.com/search/?genre_exact=Electronic)|
|## Estilo:|[Samba, Pop, Experimental](https://www.discogs.com/style/Experimental)|

## Lista de faixas

| | | | |
|---|---|---|---|
|1||A Grama do Esgoto (ft. Kassin)|<missing>|
|2||Janelas (ft. Peartree e Tuyo)|<missing>|
|3||Bailar dos Barcos (ft. Baleia)|<missing>|
|4||Roupa (ft. Morfina)|<missing>|
|5||Tudo Salta (ft. Momo)|<missing>|
|6||Girassóis|<missing>|
|7||Correntes Comprimidas (ft. Morfina)|<missing>|
|8||Força|<missing>|
|9||Contas y Conchas|<missing>|
|10||Quem Dera (ft. Figueroas)|<missing>|
|11||Onda Permanente (ft. Teago Oliveira)|<missing>|

## Companhias, etc.
[[missing]]

## Créditos

- Produtor – [Wado](https://www.discogs.com/artist/1071855-Wado)
- Ilustrações – [Moisés Crivelaro](https://www.discogs.com/artist/)
- Participações – [Kassin](https://www.discogs.com/artist/), [Peartree](https://www.discogs.com/artist/), [Tuyo](https://www.discogs.com/artist/), [Baleia](https://www.discogs.com/artist/), [Morfina](https://www.discogs.com/artist/), [Momo](https://www.discogs.com/artist/), [Figueroas](https://www.discogs.com/artist/), [Teago Oliveira](https://www.discogs.com/artist/)

## Código de Barras e Outros Identificadores
[[missing]]

## Matérias importantes
https://monkeybuzz.com.br/resenhas/albuns/wado-precariado
