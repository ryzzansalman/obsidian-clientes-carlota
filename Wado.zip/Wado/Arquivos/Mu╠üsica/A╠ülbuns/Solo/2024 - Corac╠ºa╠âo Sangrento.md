___
# [Wado](https://www.discogs.com/artist/1071855-Wado) & [Zeca Baleiro](https://www.discogs.com/artist/174582-Zeca-Baleiro) - [Coração Sangrento](https://open.spotify.com/track/0aejkKfbSlG31ARStDQ13R)

![Wado & Zeca Baleiro - Coração Sangrento album cover](<missing>)

| | |
|---|---|
|## Selo:|[Saravá Discos](https://www.isrbx.me/3138159184-zeca-baleiro-amp-wado-coracao-sangrento-2024-hi-res.html)|
|## Formato:|[Digital, CD](https://www.discogs.com/search/?format_exact=Digital)|
|## País:|[Brazil](https://www.discogs.com/search/?country_exact=Brazil)|
|## Lançado:|[1º de novembro de 2024](https://alnb.com.br/brasil/zeca-baleiro-e-wado-lancam-o-album-coracao-sangrento/)|
|## Gênero:|[MPB, Pop, Rock, Latin](https://www.isrbx.me/3138159184-zeca-baleiro-amp-wado-coracao-sangrento-2024-hi-res.html)|
|## Estilo:|[Pop, Rock](https://www.discogs.com/style/Pop)|

## Lista de faixas

| | | | |
|---|---|---|---|
|1||Coração Sangrento|<missing>|
|2||Carrossel do Tempo|<missing>|
|3||Avatar|<missing>|
|4||Dia de Sol|<missing>|
|5||Incêndios|<missing>|
|6||Congelou|<missing>|
|7||Quebra-Mar|<missing>|
|8||Alma Turva|<missing>|
|9||Zaratustra|<missing>|
|10||Amores e Celulares|<missing>|

## Companhias, etc.

- Distribuído por – [ONErpm](https://082noticias.com/2024/10/31/coracao-sangrento-disco-de-wado-e-zeca-baleiro-estreia-amanha-1o/)

## Créditos

- Produtor – [Wado](https://www.discogs.com/artist/1071855-Wado), [Zeca Baleiro](https://www.discogs.com/artist/174582-Zeca-Baleiro), [Sérgio Fouad](https://www.discogs.com/artist/)
- Baixo, Guitarra, Rhodes, Synth, Percussão, Samplers – [Sérgio Fouad](https://www.discogs.com/artist/)
- Arranjos de Cordas – [Pedro Cunha](https://www.discogs.com/artist/)
- Arranjos de Base – [Sérgio Fouad](https://www.discogs.com/artist/), [Jair Donato](https://www.discogs.com/artist/), [Zeca Baleiro](https://www.discogs.com/artist/174582-Zeca-Baleiro), [Wado](https://www.discogs.com/artist/1071855-Wado)
- Mixagem, Masterização – [Sérgio Fouad](https://www.discogs.com/artist/) com [Gabriel Galindo](https://www.discogs.com/artist/)
- Gravado em – SoundPie (São Paulo), Midas Estúdio, Dona Mix (Maceió)
- Projeto Gráfico – [Andrea Pedro](https://www.discogs.com/artist/)
- Ilustrações – [Moisés Crivelaro](https://www.discogs.com/artist/)
- Compositor – Wado, Zeca Baleiro (Todas as faixas)

## Código de Barras e Outros Identificadores

[[missing]]

## Matérias importantes
https://g1.globo.com/pop-arte/musica/blog/mauro-ferreira/post/2024/10/30/parceria-de-wado-e-zeca-baleiro-jorra-no-pulso-do-album-coracao-sangrento.ghtml