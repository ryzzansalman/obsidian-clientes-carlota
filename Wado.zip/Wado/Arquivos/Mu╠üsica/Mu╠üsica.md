___
### Álbuns
#### Solo
[[2001 - Manifesto da Arte Periférica]]
[[2002 - Cinema Auditivo]]
[[2004 - A Farsa do Samba Nublado]]
[[2008 - Terceiro Mundo Festivo]]
[[2009 - Atlântico Negro]]
[[2011 - Samba 808]]
[[2013 - Vazio Tropical]]
[[2015 - 1977]]
[[2016 - Ivete]]
[[2018 - Precariado]]
[[2018 - Wado Ao Vivo no Rex]]
[[2020 - A Beleza que Deriva do Mundo, mas a ele Escapa]]
[[2021 - Wado Acústico]]
[[2022 - Wado e o Bloco dos Bairros Distantes em - o Disco mais Feliz do Mundo, Vol 1]]
[[2023 - MARXWADO]]
[[2023 - O Clube dos Jovens de Ontem]]
[[2024 - Coração Sangrento]]
#### Fino Coletivo
[[2007 - Fino Coletivo]]
[[2010 - Copacabana]]