___
### Videoclipes

- [2007 - Se vacilar o jacaré abraça](https://www.youtube.com/watch?v=agQzrOnjEZs)
- [2009 - Fortalece aí](https://www.youtube.com/watch?v=roCpeO5Olrc&list=RDroCpeO5Olrc&start_radio=1)
- [2010 - Estrada](https://www.youtube.com/watch?v=Zlc4MH7duHY)
- [2014 - Rosa](https://www.youtube.com/watch?v=Cf1CIyoo-vM)
- [2017 - Sexo](https://www.youtube.com/watch?v=CDyMWl7671E)
- [2020 - Faz Comigo (Wado & Flora)](https://www.youtube.com/watch?v=6pL_qFuMpJU)

### Ao vivo
- [2005 - Tormenta - Avenida Club (SP) - Arquivo Radar Showlivre 2005](https://www.youtube.com/watch?v=DQEW5afegcc)
- [2010 - Martelo de Ogum (Wado, Curumin e Chamaluz)](https://www.youtube.com/watch?v=9ZZ599_zTNc)
- [2011 - Com a Ponta dos Dedos (Wado & Marcelo Camelo) - SESC Belenzinho (SP)](https://www.youtube.com/watch?v=nAo-Sc0Z3FQ)
- [2013 - Flores do Bem (Wado, Cícero e Nuno Markl) / Ponto Cego (Wado, Cícero e Nuno Markl) - Show BRASIL D'AGORA (Portugal)](https://www.youtube.com/watch?v=llld4Bcwz4k)
- [2013 - Tarja Preta (Fafá de Belém) / Fortalece Aí (Momo, Cícero e Marcelo Camelo) - SESC Pompeia (SP)](https://www.youtube.com/watch?v=yyqCJeWbxcs)
- [2017 - Calma aí, coração (Zeca Baleiro e Wado) - DVD Calma Aí, Coração](https://www.youtube.com/watch?v=mcReUu5hHQQ)
- [2017 - Wado no Cultura Livre](https://www.youtube.com/watch?v=O3alxrC70wM)
- [2018 - Ao Vivo no Rex - Rex Jazz Bar (AL) - DVD](https://www.youtube.com/watch?v=Q1d-9t74FnM&list=PLiA_O5W_AK4fK6xRuYD6QAjQV7xofksqR)
- [2021 - Quali Completo - Em casa (AL)](https://www.youtube.com/watch?v=Un9D2z2kV_Q)