___
#### [2024/11/26 - Wado transforma ícones de Alagoas em super-heróis na exposição 'Mitologia Alagoana' - Cada Minuto](https://www.cadaminuto.com.br/noticia/2024/11/26/wado-transforma-icones-de-alagoas-em-super-herois-na-exposicao-mitologia-alagoana)

#### [2024/10/30 - Parceria de Wado e Zeca Baleiro jorra no pulso do álbum ‘Coração sangrento’](https://g1.globo.com/pop-arte/musica/blog/mauro-ferreira/post/2024/10/30/parceria-de-wado-e-zeca-baleiro-jorra-no-pulso-do-album-coracao-sangrento.ghtml)

#### [2024/10/21 - Wado inaugura exposição sobre vultos históricos e culturais de Alagoas - Tribuna Hoje](https://tribunahoje.com/noticias/roteiro-cultural/2024/10/21/145694-wado-inaugura-exposicao-sobre-vultos-historicos-e-culturais-de-alagoas)

#### [2024/10/18 - Wado inaugura exposição em Penedo sobre vultos históricos e culturais de Alagoas - Correio do Povo](https://correiodopovopenedo.com.br/noticia/2024/10/18/wado-inaugura-exposicao-em-penedo-sobre-vultos-historicos-e-culturais-de-alagoas)

#### [2024/10/17 - Wado inaugura exposição em Penedo sobre vultos históricos e culturais de Alagoas - Cada Minuto](https://www.cadaminuto.com.br/noticia/2024/10/17/wado-inaugura-exposicao-em-penedo-sobre-vultos-historicos-e-culturais-de-alagoas)

#### [2023/12/21 - Ouça | Wado: "O Clube dos Jovens de Ontem" - Música Instantânea](http://musicainstantanea.com.br/ouca-wado-o-clube-dos-jovens-de-ontem/)

#### [2023/03/03 - Entrevista: Patricia Marx e Wado lançam o disco "Marxwado" - Jornal de Brasília](https://jornaldebrasilia.com.br/entretenimento/musica/patricia-marx-e-wado-lancam-o-disco-marxwado/)

#### [2021/10/30 - Wado lança projeto acústico e antecipa primeiro single, "Correntes Comprimidas" - Revista O Grito!](https://revistaogrito.com/wado-lanca-projeto-acustico-e-antecipa-primeiro-single-correntes-comprimidas/)

#### [2020/10/20 - Wado – A Beleza Que Deriva do Mundo, Mas a Ele Escapa - Monkeybuzz](https://monkeybuzz.com.br/resenhas/albuns/wado-a-beleza-que-deriva-do-mundo-mas-a-ele-escapa/)

#### [2020/10/14 - Crítica | Wado: "A Beleza que Deriva do Mundo, Mas a Ele Escapa" - Música Instantânea](http://musicainstantanea.com.br/critica-wado-a-beleza-que-deriva-do-mundo-mas-a-ele-escapa/)

#### [2018/05/23 - Wado: "Precariado" - Música Instantânea](http://musicainstantanea.com.br/wado-precariado/)

#### [2016/08/01 - Wado – Ivete: Músico homenageia o Axé e nos apresenta seu olhar único sobre o estilo - Monkeybuzz](https://monkeybuzz.com.br/resenhas/albuns/wado-ivete/)

#### [2016/07/13 - Resenha: "Ivete", Wado - Música Instantânea](http://musicainstantanea.com.br/resenha-ivete-wado/)

#### [2016/06/25 - Eis a capa de 'Ivete', álbum inspirado pela axé music que Wado lança em julho - Notas Musicais](http://www.blognotasmusicais.com.br/2016/06/eis-capa-de-ivete-album-inspirado-pela.html)

#### [2015/10/28 - Entrevista: Wado (2015) - Scream & Yell](https://screamyell.com.br/site/2015/10/28/entrevista-wado-2015/)

#### [2015/04/15 - Conheça o Músico Wado! - Moda Aprovada](https://www.modaaprovada.com/2015/04/conheca-o-musico-wado.html)

#### [2014/08/29 - Em bom brasuguês: Cícero, Wado e Momo andam a mudar a música brasileira - Público](https://www.publico.pt/2014/08/29/culturaipsilon/entrevista/o-brasugues-de-o-clube-e-outra-bossa-no-caldo-portusileiro-1667548)

#### [2014/05/27 - Cícero, Wado e Momo lançam o disco "O Clube" - Música Pavê](https://musicapave.com/semibreves/cicero-wado-e-momo-lancam-o-disco-o-clube/)

#### [2013/07/31 - Wado lança "Vazio Tropical" produzido por Marcelo Camelo - Monkeybuzz](https://monkeybuzz.com.br/resenhas/albuns/wado-vazio-tropical/)

#### [2009/11/07 - O cantor e compositor Wado refaz a ponte entre a África e as Américas em seu quinto disco - Correio Braziliense](https://www.correiobraziliense.com.br/app/noticia/diversao-e-arte/2009/11/07/interna_diversao_arte,153258/o-cantor-e-compositor-wado-refaz-a-ponte-entre-a-africa-e-as-americas-em-seu-quinto-disco.shtml)

#### [2009/11/03 - Entrevista: Wado (2009) - Scream & Yell](https://screamyell.com.br/site/2009/11/03/entrevista-wado/)